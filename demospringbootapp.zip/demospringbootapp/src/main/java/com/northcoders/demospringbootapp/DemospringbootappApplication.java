package com.northcoders.demospringbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringbootappApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemospringbootappApplication.class, args);
	}

}
